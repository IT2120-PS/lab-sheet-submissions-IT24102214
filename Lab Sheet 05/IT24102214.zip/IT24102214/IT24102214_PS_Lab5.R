
setwd("C:\\Users\\User\\Desktop\\IT24102214")

data <- read.table("Data.txt", header = TRUE, sep = ",")
fix(data)
attach(data)


names(data) <- c("X1", "X2")
attach(data)

hist(X2, main = "Histogram for Number of Shareholders", xlab = "Number of Shareholders (thousands)")

histogram <- hist(X2,main = "Histogram for Number of Shareholders", 
                  xlab = "Number of Shareholders (thousands)",
                  breaks = seq(130, 270, length = 8), 
                  right = FALSE )

breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids







classes <- c()

for(i in 1 : length(breaks)-1 ){
  classes[i] <- paste("[", breaks[i], ",", breaks[i+1], ")") 
}

frequency_dist <- cbind(Classes = classes, Frequency = freq)
print(frequency_dist)

lines(mids,freq)
